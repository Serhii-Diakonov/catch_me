
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.lang.management.ManagementFactory;


public class Game {

    public static void main(String[] args){
        EventQueue.invokeLater(() -> {
            /*
             *Створюємо головний фрейм,
             * у якому здійснюватиметься малювання
             * */
            JFrame frame = new MainFrame("Catch me!");
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setResizable(false);
            frame.setVisible(true);
        });
    }

    public static void restart(){
        StringBuilder cmd = new StringBuilder();
        /* Створює рядок D:\Programs\JDK\bin\java */
        cmd.append(System.getProperty("java.home") + File.separator + "bin" + File.separator + "java ");

        /* Рядок D:\Programs\JDK\bin\java -Dfile.encoding=windows-1251 */
        for (String jvmArg : ManagementFactory.getRuntimeMXBean().getInputArguments()) {
            cmd.append(jvmArg + " ");
        }

        /* Рядок D:\Programs\JDK\bin\java -Dfile.encoding=windows-1251
         -cp D:\#JAVA\IdeaProjects\catchme\out\artifacts\catchme_jar\catchme.jar */
        cmd.append("-cp ").append(ManagementFactory.getRuntimeMXBean().getClassPath()).append(" ");

        /* Рядок D:\Programs\JDK\bin\java -Dfile.encoding=windows-1251
        -cp D:\#JAVA\IdeaProjects\catchme\out\artifacts\catchme_jar\catchme.jar Game */
        cmd.append(Game.class.getName()).append(" ");
        try{
            Runtime.getRuntime().exec(cmd.toString());
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
        finish();
    }

    /*
     *Метод завершує виконання програми,
     * коли його викликають.
     * Викликається натисканням клавіши 'Esc'
     * через обробник подій у головному фреймі
     *
     * */
    public static void finish(){
        System.exit(0);
    }
}
